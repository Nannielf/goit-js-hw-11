export const selectors = {
    form: document.querySelector('.search-form'),
    searchFormButtonSubmit: document.querySelector('.search-form__submit'),
    input: document.querySelector('.input'),
    gallery: document.querySelector('.gallery'),
    loadMoreBtn: document.querySelector('.load-more'),
  };